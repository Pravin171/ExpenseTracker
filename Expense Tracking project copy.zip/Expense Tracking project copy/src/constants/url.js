export const adminUrl = "http://122.165.52.124:4000/api/v1/"; 
export const loginUrl = "";
