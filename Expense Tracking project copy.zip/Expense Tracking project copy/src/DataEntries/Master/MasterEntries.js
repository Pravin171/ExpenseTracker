export const MovieTableHeaders = [
    "S.No",
    "Movie Name",
    "Status",
    "Created Date",
    "Actions",
  ];
  
  export const LocationTableHeaders = [
    "S.No",
    "Movie Name",
    "Location",
    "Mobile Number",
    "Created Date",
    "Actions",
  ];
  export const CategoryTableHeaders = [
    "S.No",
    "Movie Name",
    "Category",
    "Created Date",
    "Actions",
  ];
  export const SubCategoryTableHeaders = [
    "S.No",
    "Movie Name",
    "Category",
    "Subcategory",
    "Created Date",
    "Actions",
  ];
  export const CrewTableHeaders = [
    "S.No",
    "Movie Name",
    
    "Category",
    "Subcategory",
    "Crew Name",
    "Gender",
    "Mobile Number",
    
    "Created Date",
    "Actions",
  ];
  
  