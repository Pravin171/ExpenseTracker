export const ExpenseSheetTableHeaders = [
    "S.No",
    "Movie Name",
    "Location",
    "Date",
    "Crew Name",
    "Category",
    "Subcategory",
    "Number of Persons",
    "Advance",
    "Beta",
    "Actions",
  ];
  
 
 